package orquita;

import com.fazecast.jSerialComm.SerialPort;
import java.io.PrintWriter;

public class ArduinoSerial {

    // Cada cuanto se manda PING para mantener vivo el enlace
    // (el Arduino frena los motores si pasan 3 s sin recibir nada)
    private static final long PERIODO_PING_MS = 1000;

    private SerialPort puerto;
    private PrintWriter salida;

    // Hilo que lee todo lo que manda el Arduino
    private volatile boolean leyendo = false;
    private Thread hiloLectura;

    // Capturas (canicas detectadas por el sensor IR) que el Cliente
    // todavia no informo al servidor
    private int capturasPendientes = 0;
    private int ultimoNumeroCaptura = -1;

    // Ultimo barrido completo del sensor ultrasonico (SWP)
    private final Object lockBarrido = new Object();
    private double[] ultimoBarrido = null;
    private long contadorBarridos = 0;


    public ArduinoSerial(String puertoCOM) {

        puerto = SerialPort.getCommPort(puertoCOM);

        puerto.setBaudRate(9600);
        puerto.setNumDataBits(8);
        puerto.setNumStopBits(SerialPort.ONE_STOP_BIT);
        puerto.setParity(SerialPort.NO_PARITY);

        // Lectura sin bloqueo: el hilo consulta bytesAvailable()
        puerto.setComPortTimeouts(
                SerialPort.TIMEOUT_NONBLOCKING,
                0,
                0
        );

        System.out.println("Intentando abrir: " + puertoCOM);

        if (puerto.openPort()) {

            System.out.println("Arduino conectado correctamente.");

            salida = new PrintWriter(
                    puerto.getOutputStream(),
                    true
            );

            iniciarLectura();

        } else {

            throw new RuntimeException(
                    "No se pudo abrir el puerto: "
                            + puertoCOM
            );
        }
    }


    // ======================= HILO DE LECTURA =======================

    private void iniciarLectura() {

        leyendo = true;

        hiloLectura = new Thread(this::bucleLectura, "lectura-arduino");
        hiloLectura.setDaemon(true);
        hiloLectura.start();
    }

    private void bucleLectura() {

        StringBuilder linea = new StringBuilder();
        byte[] buffer = new byte[256];
        long ultimoPing = 0;

        while (leyendo && puerto != null && puerto.isOpen()) {

            try {

                long ahora = System.currentTimeMillis();

                if (ahora - ultimoPing >= PERIODO_PING_MS) {
                    enviar("PING");
                    ultimoPing = ahora;
                }

                int disponibles = puerto.bytesAvailable();

                if (disponibles <= 0) {
                    Thread.sleep(20);
                    continue;
                }

                int n = puerto.readBytes(
                        buffer,
                        Math.min(disponibles, buffer.length)
                );

                for (int i = 0; i < n; i++) {

                    char c = (char) (buffer[i] & 0xFF);

                    if (c == '\n') {

                        procesarLinea(linea.toString().trim());
                        linea.setLength(0);

                    } else if (c != '\r') {

                        if (linea.length() < 200) {
                            linea.append(c);
                        } else {
                            linea.setLength(0);   // linea absurda: se descarta
                        }
                    }
                }

            } catch (InterruptedException e) {

                Thread.currentThread().interrupt();
                break;

            } catch (Exception e) {

                System.out.println(
                        "[ARDUINO] Error leyendo: " + e.getMessage()
                );

                try {
                    Thread.sleep(100);
                } catch (InterruptedException ie) {
                    Thread.currentThread().interrupt();
                    break;
                }
            }
        }
    }

    private void procesarLinea(String linea) {

        if (linea.isEmpty()) {
            return;
        }

        // Barrido completo del sensor: no se imprime la linea cruda
        if (procesarBarrido(linea)) {
            return;
        }

        registrarCaptura(linea);

        // Ruido de protocolo que no hace falta mostrar
        if (linea.contains("TEL,") || linea.contains("PONG")) {
            return;
        }

        // Si la placa se reinicia, su contador de capturas vuelve a 0
        if (linea.contains("READY")) {

            synchronized (this) {
                ultimoNumeroCaptura = -1;
            }

            System.out.println(
                    "[ARDUINO] READY recibido: la placa arranco "
                    + "(o se reinicio)."
            );
        }

        System.out.println("Arduino> " + linea);
    }


    // ======================= BARRIDO (SWP) =======================

    /**
     * Linea del sketch: SWP,n,d0,d1,d2,d3,d4,d5,d6,ir
     * d0 = extremo izquierdo ... d6 = extremo derecho. -1 = sin eco.
     * Devuelve true si la linea era un barrido.
     */
    private boolean procesarBarrido(String linea) {

        int inicio = linea.indexOf("SWP,");   // tolera bytes danados antes
        if (inicio < 0) {
            return false;
        }

        String[] p = linea.substring(inicio).trim().split(",");

        // SWP + n + 7 distancias + ir = 10 campos
        if (p.length != 10) {
            System.out.println("[ARDUINO] SWP incompleto, se ignora: " + linea);
            return true;
        }

        try {

            double[] d = new double[7];

            for (int i = 0; i < 7; i++) {
                d[i] = Double.parseDouble(p[2 + i].trim());
            }

            synchronized (lockBarrido) {
                ultimoBarrido = d;
                contadorBarridos++;
                lockBarrido.notifyAll();
            }

        } catch (NumberFormatException e) {
            System.out.println("[ARDUINO] SWP invalido, se ignora: " + linea);
        }

        return true;
    }

    /**
     * Espera un barrido NUEVO (nunca devuelve uno viejo).
     * descartar = cuantos barridos completos se salta antes de usar uno.
     * Devuelve null si vence el tiempo.
     */
    public double[] esperarBarrido(long timeoutMs, int descartar) {

        long limite = System.currentTimeMillis() + timeoutMs;

        synchronized (lockBarrido) {

            long objetivo = contadorBarridos + 1 + descartar;

            while (contadorBarridos < objetivo) {

                long resto = limite - System.currentTimeMillis();

                if (resto <= 0) {
                    return null;
                }

                try {
                    lockBarrido.wait(resto);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    return null;
                }
            }

            return ultimoBarrido.clone();
        }
    }


    // ======================= CAPTURAS (CAP) =======================

    /**
     * Revisa si la linea es una captura del sensor IR (formato CAP,n).
     * El numero n evita contar dos veces la misma captura y permite
     * recuperar capturas si se perdio alguna linea.
     */
    private synchronized void registrarCaptura(String linea) {

        int pos = linea.indexOf("CAP,");

        if (pos < 0) {
            return;
        }

        try {

            int numero = Integer.parseInt(
                    linea.substring(pos + 4).trim()
            );

            if (numero > ultimoNumeroCaptura) {

                int nuevas = (ultimoNumeroCaptura < 0)
                        ? 1
                        : numero - ultimoNumeroCaptura;

                if (nuevas > 3) {
                    nuevas = 1;   // salto raro: linea danada
                }

                capturasPendientes += nuevas;
                ultimoNumeroCaptura = numero;

                System.out.println(
                        "[IR] Canica detectada (CAP," + numero + ")"
                );

            } else if (numero < ultimoNumeroCaptura) {

                // El contador del Arduino volvio atras: se reinicio
                ultimoNumeroCaptura = numero;
                capturasPendientes++;

                System.out.println(
                        "[IR] Canica detectada (CAP," + numero
                        + ", contador reiniciado)"
                );
            }

        } catch (NumberFormatException e) {
            // linea danada: se ignora
        }
    }

    /**
     * Devuelve cuantas capturas nuevas hubo desde la ultima llamada
     * y reinicia el contador.
     */
    public synchronized int consumirCapturas() {

        int n = capturasPendientes;
        capturasPendientes = 0;
        return n;
    }


    // ======================= ENVIO / CIERRE =======================

    public void enviar(String mensaje) {

        if (salida != null) {

            salida.println(mensaje);
        }
    }

    public void cerrar() {

        leyendo = false;

        if (hiloLectura != null) {

            hiloLectura.interrupt();

            try {
                hiloLectura.join(500);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }

        if (salida != null) {
            salida.close();
        }

        if (puerto != null && puerto.isOpen()) {

            puerto.closePort();

            System.out.println("Puerto cerrado.");
        }
    }
}