package orquita;

import java.util.Random;

public class SensorHcsr04 {

    private final Random random = new Random();

  
    public double leerDistancia(int anguloGrados) {

        double base = 20 + random.nextDouble() * 60;
        double ruido = (random.nextDouble() - 0.5) * 2;
        return Math.max(2.0, base + ruido);
    }
}