package servidororquita;

public class Protocolo {

    public static final String TLM = "TLM";
    public static final String CAPTURA = "CAPTURA";
    public static final String EST = "EST";
    public static final String ORD = "ORD";
    public static final String ACK = "ACK";
    public static final String HEARTBEAT = "HEARTBEAT";

    public static final String AVANZAR = "AVANZAR";
    public static final String IZQUIERDA = "IZQUIERDA";
    public static final String DERECHA = "DERECHA";
    public static final String RETROCEDER = "RETROCEDER";
    public static final String DETENER = "DETENER";
    public static final String ESCAPE = "ESCAPE";
    public static final String CAPTURAR = "CAPTURAR";

    private Protocolo() {
    }

    public static String orden(String accion) {

        if (accion == null || accion.trim().isEmpty()) {
            return null;
        }

        accion = accion.trim().toUpperCase();

        if (!esAccionValida(accion)) {
            return null;
        }

        return ORD + "|accion=" + accion;
    }

    public static String ack(String evento) {

        if (evento == null || evento.trim().isEmpty()) {
            return null;
        }

        return ACK + "|" + evento.trim();
    }

    public static boolean esMensajeValido(String mensaje) {

        if (mensaje == null) {
            return false;
        }

        mensaje = mensaje.trim();

        if (mensaje.isEmpty()) {
            return false;
        }

        if (mensaje.startsWith(TLM + "|")) {

            String[] partes = mensaje.split("\\|");

            if (partes.length != 10) {
                return false;
            }

            for (int i = 1; i < partes.length; i++) {

                try {

                    double valor = Double.parseDouble(partes[i]);

                    if (Double.isNaN(valor) || Double.isInfinite(valor)) {
                        return false;
                    }

                    if (valor < 0) {
                        return false;
                    }

                } catch (NumberFormatException e) {

                    return false;
                }
            }

            return true;
        }

        if (mensaje.equals(CAPTURA + "|LOBITO")) {
            return true;
        }

        if (mensaje.startsWith(EST + "|")) {

            String[] partes = mensaje.split("\\|");

            return partes.length >= 2
                    && !partes[1].trim().isEmpty();
        }

        if (mensaje.startsWith(ACK + "|")) {

            String[] partes = mensaje.split("\\|");

            return partes.length >= 2
                    && !partes[1].trim().isEmpty();
        }

        if (mensaje.equals(HEARTBEAT)) {
            return true;
        }

        return false;
    }

    public static boolean esAccionValida(String accion) {

        if (accion == null) {
            return false;
        }

        accion = accion.trim().toUpperCase();

        return accion.equals(AVANZAR)
                || accion.equals(IZQUIERDA)
                || accion.equals(DERECHA)
                || accion.equals(RETROCEDER)
                || accion.equals(DETENER)
                || accion.equals(ESCAPE)
                || accion.equals(CAPTURAR);
    }

    public static String obtenerAccion(String mensaje) {

        if (mensaje == null) {
            return null;
        }

        mensaje = mensaje.trim();

        if (!mensaje.startsWith(ORD + "|")) {
            return null;
        }

        String[] partes = mensaje.split("\\|");

        for (String parte : partes) {

            if (parte.startsWith("accion=")) {

                return parte.substring("accion=".length())
                        .trim()
                        .toUpperCase();
            }
        }

        return null;
    }
}