package orquita;

import com.fazecast.jSerialComm.SerialPort;

import java.util.Scanner;

public class PruebaBluetooth {

    // Ruta del puerto Bluetooth en Mac (ver con: ls /dev/cu.*)
    private static final String RUTA = "/dev/cu.HC-05";


    public static void main(String[] args) throws Exception {

        Scanner teclado = new Scanner(System.in);

        System.out.println("=== PRUEBA BLUETOOTH ORQUITA ===");

        // ------------------------------------------------------------
        // Lista los puertos que Java realmente ve y comprueba que exista
        // ------------------------------------------------------------
        System.out.println("Puertos disponibles:");

        boolean encontrado = false;

        for (SerialPort p : SerialPort.getCommPorts()) {

            String ruta = p.getSystemPortPath();

            System.out.println("  - " + ruta);

            if (ruta.equals(RUTA)) {
                encontrado = true;
            }
        }

        if (!encontrado) {
            System.out.println(
                    "ERROR: no existe " + RUTA + ". "
                    + "Empareja el HC-05 en Ajustes del Sistema > Bluetooth "
                    + "(PIN 1234 o 0000) y copia el nombre exacto de la lista de arriba."
            );
            return;
        }

        System.out.println("Puerto Bluetooth detectado: " + RUTA);

        Bluetooth bt = new Bluetooth(RUTA);

        System.out.println("Abriendo conexion Bluetooth...");

        try {
            bt.conectar();
        } catch (Exception e) {
            System.out.println("ERROR al conectar: " + e.getMessage());
            return;
        }

        System.out.println("Conectado a " + RUTA);


        // ============================================================
        // HILO LECTOR
        // Muestra lo que manda Arduino
        // ============================================================

        Thread lector = new Thread(() -> {

            try {

                int contadorTel = 0;
                String linea;

                while ((linea = bt.recibir()) != null) {

                    linea = linea.trim();

                    if (linea.isEmpty()) {
                        continue;
                    }

                    // La telemetria llega cada 200 ms: se muestra 1 de cada 10
                    if (linea.startsWith("TEL,")) {

                        contadorTel++;

                        if (contadorTel % 10 != 0) {
                            continue;
                        }
                    }

                    System.out.println("Arduino> " + linea);
                }

                System.out.println("El Arduino cerro la conexion.");

            } catch (Exception e) {

                if (bt.isConectado()) {
                    System.out.println("Lector detenido: " + e.getMessage());
                }
            }
        });

        lector.setDaemon(true);
        lector.start();


        // ============================================================
        // HILO PING
        // Mantiene vivo el enlace (el watchdog del Arduino es de 1500 ms)
        // ============================================================

        Thread ping = new Thread(() -> {

            try {

                while (bt.isConectado()) {

                    bt.enviar("PING");

                    Thread.sleep(500);
                }

            } catch (Exception e) {

                if (bt.isConectado()) {
                    System.out.println("PING detenido: " + e.getMessage());
                }
            }
        });

        ping.setDaemon(true);
        ping.start();


        // ============================================================
        // CONSOLA
        // Envia comandos CMD,<comando>
        // ============================================================

        System.out.println("Escribi un comando (ej: forward) o 'salir'.");

        while (teclado.hasNextLine()) {

            String entrada = teclado.nextLine().trim();

            if (entrada.equalsIgnoreCase("salir")) {
                break;
            }

            if (!entrada.isEmpty()) {

                try {

                    String comando = "CMD," + entrada.toUpperCase();

                    bt.enviar(comando);

                    System.out.println("[ENVIADO] " + comando);

                } catch (Exception e) {

                    System.out.println("Error al enviar: " + e.getMessage());
                }
            }
        }

        bt.desconectar();

        System.out.println("Desconectado.");
    }

}