package orquita;


public class Sensor {


    public double obtenerDistancia(String mensaje){

        try{

            String valor =
            mensaje.split("=")[1];

            return Double.parseDouble(valor);


        }catch(Exception e){

            return -1;
        }

    }

}