#include <Servo.h>

const int TRIG = 9;
const int ECHO = 10;

Servo servoSensor;

int posiciones[] = {60,70,80,90,100,110,120};

float sensores[7];

long duracion;


void setup(){

  Serial.begin(9600);

  pinMode(TRIG,OUTPUT);
  pinMode(ECHO,INPUT);

  servoSensor.attach(6);

  servoSensor.write(90);

  delay(1000);

}



float medirDistancia(){

  digitalWrite(TRIG,LOW);
  delayMicroseconds(2);

  digitalWrite(TRIG,HIGH);
  delayMicroseconds(10);

  digitalWrite(TRIG,LOW);


  duracion = pulseIn(ECHO,HIGH,30000);


  if(duracion==0){
    return 400;
  }


  float distancia = duracion * 0.034 / 2;


  if(distancia>400){
    distancia=400;
  }


  return distancia;

}



void loop(){


  for(int i=0;i<7;i++){


    servoSensor.write(posiciones[i]);

    delay(300);


    sensores[i]=medirDistancia();


    // SOLO MANDA LA DISTANCIA
    Serial.print("DISTANCIA:");
    Serial.println(sensores[i]);


  }



  float minimo=sensores[0];


  for(int i=1;i<7;i++){

    if(sensores[i]<minimo){
      minimo=sensores[i];
    }

  }



  Serial.print("TLM|");


  for(int i=0;i<7;i++){

    Serial.print(sensores[i]);

    if(i<6){
      Serial.print("|");
    }

  }


  Serial.println();



  delay(500);

}