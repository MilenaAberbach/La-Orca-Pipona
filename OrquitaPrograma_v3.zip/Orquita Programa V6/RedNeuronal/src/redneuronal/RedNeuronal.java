package redneuronal;

import org.neuroph.core.NeuralNetwork;

public class RedNeuronal {

    private NeuralNetwork red;

    public RedNeuronal(String rutaModelo) {
        red = NeuralNetwork.load(rutaModelo);
    }

    public double clasificarElemento(double[] sensores) {

        if (sensores == null || sensores.length != 9) {
            return -1;
        }

        red.setInput(sensores);
        red.calculate();

        double[] salida = red.getOutput();

        return salida[0];
    }
}

