package orquita;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import com.fazecast.jSerialComm.SerialPort;

public class PuertoSerial {

    private SerialPort puerto;

    private BufferedReader br;

    private PrintWriter pw;

    public void conectar(String puertoCOM){

        puerto = SerialPort.getCommPort(puertoCOM);

        puerto.setBaudRate(9600);

        puerto.setNumDataBits(8);

        puerto.setNumStopBits(SerialPort.ONE_STOP_BIT);

        puerto.setParity(SerialPort.NO_PARITY);

        puerto.setComPortTimeouts(

                SerialPort.TIMEOUT_READ_SEMI_BLOCKING,

                3000,

                0

        );

        if(!puerto.openPort()){

            throw new RuntimeException(

                    "No se pudo abrir "

                    + puertoCOM

            );

        }

        br = new BufferedReader(

                new InputStreamReader(

                        puerto.getInputStream()

                )

        );

        pw = new PrintWriter(

                puerto.getOutputStream(),

                true

        );

        System.out.println(

                "Conectado a "

                + puertoCOM

        );

    }

    public String leer(){

        try{

            return br.readLine();

        }catch(Exception e){

            return null;

        }

    }

    public void enviar(String mensaje){

        pw.println(mensaje);

    }

    public void cerrar(){

        try{

            if(br!=null)

                br.close();

        }catch(Exception e){}

        if(pw!=null)

            pw.close();

        if(puerto!=null)

            puerto.closePort();

    }

}