package servidororquita;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class PersistenciaEstomago {

    private static final String ARCHIVO = "estomago.txt";

    private static final Object LOCK = new Object();

    public static void registrarCaptura(String captura) {

        synchronized (LOCK) {

            try {

                File archivo = new File(ARCHIVO);

                if (!archivo.exists()) {
                    archivo.createNewFile();
                }

                FileWriter fw =
                        new FileWriter(archivo, true);

                PrintWriter pw =
                        new PrintWriter(fw);

                pw.println(captura);

                pw.close();

                System.out.println(
                        "Captura guardada en:"
                );

                System.out.println(
                        archivo.getAbsolutePath()
                );

            } catch (IOException e) {

                System.out.println(
                        "Error escribiendo estomago.txt: "
                        + e.getMessage()
                );

                e.printStackTrace();
            }
        }
    }

    public static int contarCapturas() {

        synchronized (LOCK) {

            File archivo = new File(ARCHIVO);

            if (!archivo.exists()) {
                return 0;
            }

            int contador = 0;

            try {

                BufferedReader br =
                        new BufferedReader(
                                new FileReader(archivo)
                        );

                String linea;

                while ((linea = br.readLine()) != null) {

                    if (linea.startsWith("LOBITO|")) {
                        contador++;
                    }
                }

                br.close();

            } catch (IOException e) {

                System.out.println(
                        "Error leyendo estomago.txt: "
                        + e.getMessage()
                );
            }

            return contador;
        }
    }
}