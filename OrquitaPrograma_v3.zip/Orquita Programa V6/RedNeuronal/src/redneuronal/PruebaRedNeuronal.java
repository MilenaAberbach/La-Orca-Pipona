package redneuronal;

import org.neuroph.core.NeuralNetwork;
import org.neuroph.core.data.DataSet;
import org.neuroph.core.data.DataSetRow;
import org.neuroph.util.data.norm.MaxMinNormalizer;
import org.neuroph.util.data.norm.Normalizer;

public class PruebaRedNeuronal {

    public static void main(String[] args) {

        String rutaDataset =
                "/home/usrlocal/Descargas//Dataset.csv";

        String rutaRed =
                "/home/usrlocal/Descargas//red_orquita.nnet";

        try {

            DataSet dataset = DataSet.createFromFile(
                    rutaDataset,
                    9,
                    1,
                    ","
            );

            System.out.println("Dataset cargado correctamente.");
            System.out.println("Cantidad de registros: "
                    + dataset.getRows().size());


            Normalizer normalizer =
                    new MaxMinNormalizer(dataset);

            normalizer.normalize(dataset);

            System.out.println("Dataset normalizado correctamente.");

            NeuralNetwork red =
                    NeuralNetwork.createFromFile(rutaRed);

            System.out.println("Red neuronal cargada correctamente.");


            int total = 0;

            int correctos = 0;
            int incorrectos = 0;

            int correctosClase0 = 0;
            int incorrectosClase0 = 0;

            int correctosClase1 = 0;
            int incorrectosClase1 = 0;


            System.out.println();
            System.out.println("==========================================");
            System.out.println("       COMENZANDO PRUEBA DE LA RED");
            System.out.println("==========================================");
            System.out.println();


            for (DataSetRow fila : dataset.getRows()) {

                double[] entrada = fila.getInput();

                double[] salidaEsperada =
                        fila.getDesiredOutput();

                int claseReal =
                        salidaEsperada[0] >= 0.5 ? 1 : 0;


                red.setInput(entrada);

                red.calculate();

                double[] salidaRed =
                        red.getOutput();

                double valorSalida =
                        salidaRed[0];

                int clasePredicha =
                        valorSalida >= 0.5 ? 1 : 0;

                total++;

                if (claseReal == clasePredicha) {

                    correctos++;

                    if (claseReal == 0) {
                        correctosClase0++;
                    } else {
                        correctosClase1++;
                    }

                } else {

                    incorrectos++;

                    if (claseReal == 0) {
                        incorrectosClase0++;
                    } else {
                        incorrectosClase1++;
                    }
                }


                System.out.printf(
                        "Registro %3d | Real: %d | "
                        + "Salida: %.6f | Predicha: %d | %s%n",
                        total,
                        claseReal,
                        valorSalida,
                        clasePredicha,
                        claseReal == clasePredicha
                                ? "OK"
                                : "ERROR"
                );
            }


            double porcentaje =
                    ((double) correctos / total) * 100.0;

            System.out.println();
            System.out.println("==========================================");
            System.out.println("           RESULTADO DE LA PRUEBA");
            System.out.println("==========================================");

            System.out.println(
                    "Total de registros: "
                    + total
            );

            System.out.println(
                    "Clasificados correctamente: "
                    + correctos
            );

            System.out.println(
                    "Clasificados incorrectamente: "
                    + incorrectos
            );

            System.out.printf(
                    "Porcentaje de acierto: %.2f %% %n",
                    porcentaje
            );

            System.out.println();
            System.out.println("------------------------------------------");
            System.out.println("Clase 0");
            System.out.println("------------------------------------------");

            System.out.println(
                    "Correctos: "
                    + correctosClase0
            );

            System.out.println(
                    "Incorrectos: "
                    + incorrectosClase0
            );


            System.out.println();
            System.out.println("------------------------------------------");
            System.out.println("Clase 1");
            System.out.println("------------------------------------------");

            System.out.println(
                    "Correctos: "
                    + correctosClase1
            );

            System.out.println(
                    "Incorrectos: "
                    + incorrectosClase1
            );

            System.out.println();
            System.out.println("==========================================");

            if (porcentaje >= 90.0) {

                System.out.println(
                        "La red aprendió muy bien los datos."
                );

            } else if (porcentaje >= 75.0) {

                System.out.println(
                        "La red tiene un aprendizaje aceptable,"
                        + " pero hay errores."
                );

            } else {

                System.out.println(
                        "La red tiene dificultades para"
                        + " clasificar correctamente."
                );
            }

            System.out.println("==========================================");

        } catch (Exception e) {

            System.out.println();
            System.out.println(
                    "ERROR DURANTE LA PRUEBA"
            );

            System.out.println(
                    "Detalle: " + e.getMessage()
            );

            e.printStackTrace();
        }
    }
}