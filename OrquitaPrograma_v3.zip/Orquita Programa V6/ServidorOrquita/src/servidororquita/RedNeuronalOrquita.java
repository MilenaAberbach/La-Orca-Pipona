package servidororquita;

import org.neuroph.core.NeuralNetwork;
import org.neuroph.nnet.MultiLayerPerceptron;

public class RedNeuronalOrquita {

    private MultiLayerPerceptron red;

    public RedNeuronalOrquita(String rutaModelo) {

        try {

            red = (MultiLayerPerceptron) NeuralNetwork.load(rutaModelo);

            System.out.println(
                    "[NEUROPH] Red neuronal cargada correctamente."
            );

        } catch (Exception e) {

            System.out.println(
                    "[NEUROPH] ERROR al cargar la red neuronal:"
            );

            red = null;
            e.printStackTrace();
        }
    }

    public double clasificar(double[] entradas) {

        if (red == null) {

            System.out.println(
                    "[NEUROPH] La red neuronal no está cargada."
            );

            return -1;
        }

        if (entradas == null || entradas.length != 9) {

            System.out.println(
                    "[NEUROPH] ERROR: se esperaban 9 entradas."
            );

            return -1;
        }

        double[] normalizadas = new double[9];

        double[] min = {
            5.8, 3.0, 3.0, 3.0, 3.0,
            4.0, 7.1, 3.0, 0.2
        };

        double[] max = {
            76.0, 75.3, 75.1, 74.8, 75.2,
            76.0, 76.6, 74.2, 16.3
        };
        boolean yaNormalizadas = true;

        for (int i = 0; i < 9; i++) {

            if (entradas[i] < 0.0 || entradas[i] > 1.0) {

                yaNormalizadas = false;
                break;
            }
        }

        if (yaNormalizadas) {

            System.out.println(
                    "[NEUROPH] Entradas detectadas como NORMALIZADAS."
            );

            for (int i = 0; i < 9; i++) {

                normalizadas[i] = entradas[i];
            }

        } else {

            System.out.println(
                    "[NEUROPH] Entradas detectadas como VALORES REALES."
            );

            for (int i = 0; i < 9; i++) {

                double valor = entradas[i];

                if (valor < min[i]) {
                    valor = min[i];
                }

                if (valor > max[i]) {
                    valor = max[i];
                }

                normalizadas[i] =
                        (valor - min[i])
                        / (max[i] - min[i]);
            }
        }

        System.out.println("[NEUROPH] Entradas a la red:");

        for (int i = 0; i < 9; i++) {

            System.out.println(
                    "  Entrada[" + i + "] = "
                    + normalizadas[i]
            );
        }

        red.setInput(normalizadas);

        red.calculate();

        double[] salida = red.getOutput();

        if (salida == null || salida.length == 0) {

            System.out.println(
                    "[NEUROPH] ERROR: la red no produjo una salida."
            );

            return -1;
        }

        System.out.println(
                "[NEUROPH] Salida de la red = "
                + salida[0]
        );

        return salida[0];
    }
}