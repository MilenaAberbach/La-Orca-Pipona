package redneuronal;

import org.neuroph.core.Layer;
import org.neuroph.core.Neuron;
import org.neuroph.core.data.DataSet;
import org.neuroph.core.events.LearningEvent;
import org.neuroph.core.events.LearningEventListener;
import org.neuroph.core.transfer.Sigmoid;
import org.neuroph.nnet.MultiLayerPerceptron;
import org.neuroph.nnet.learning.MomentumBackpropagation;

public class NeuroOrquita {

    public static void main(String[] args) {

        DataSet trainingSet = DataSet.createFromFile(
                "/home/tt_linares/Descargas/Dataset.csv",
                9,      
                1,      
                ","    
        );

        System.out.println("Dataset normalizado cargado correctamente.");

        MultiLayerPerceptron red =
                new MultiLayerPerceptron(9, 12, 1);

        Layer capaOculta = red.getLayerAt(1);

        for (Neuron n : capaOculta.getNeurons()) {
            n.setTransferFunction(new Sigmoid());
        }

      
        Layer capaSalida = red.getLayerAt(2);

        for (Neuron n : capaSalida.getNeurons()) {
            n.setTransferFunction(new Sigmoid());
        }

        MomentumBackpropagation bp =
                new MomentumBackpropagation();

        bp.setMaxIterations(1000);
        bp.setLearningRate(0.2);
        bp.setMomentum(0.7);
        bp.setMaxError(0.002);

        bp.addListener(new LearningEventListener() {

            @Override
            public void handleLearningEvent(LearningEvent event) {

                MomentumBackpropagation source =
                        (MomentumBackpropagation) event.getSource();

                int it = source.getCurrentIteration();

                if (it % 10 == 0) {

                    System.out.println(
                            "Iteración: " + it
                            + " | Error: "
                            + String.format(
                                    "%.10f",
                                    source.getTotalNetworkError()
                            )
                    );

                    try {
                        Thread.sleep(50);
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                    }
                }
            }
        });

        red.setLearningRule(bp);

        System.out.println();
        System.out.println("======================================");
        System.out.println("   COMENZANDO ENTRENAMIENTO");
        System.out.println("======================================");

        red.learn(trainingSet);

        System.out.println();
        System.out.println("======================================");
        System.out.println("   ENTRENAMIENTO TERMINADO");
        System.out.println("======================================");

        System.out.println(
                "Iteraciones realizadas: "
                + bp.getCurrentIteration()
        );

        System.out.println(
                "Error final: "
                + String.format(
                        "%.10f",
                        bp.getTotalNetworkError()
                )
        );

        // =====================================================
        // GUARDAR RED
        // =====================================================

        try {

            String rutaRed =
                    "/home/tt_linares/Vídeos/red_orquita.nnet";

            red.save(rutaRed);

            System.out.println();
            System.out.println(
                    "Red neuronal guardada correctamente."
            );

            System.out.println(
                    "Archivo: " + rutaRed
            );

        } catch (Exception e) {

            System.out.println();
            System.out.println(
                    "ERROR al guardar la red neuronal."
            );

            System.out.println(
                    "Detalle: " + e.getMessage()
            );

            e.printStackTrace();
        }
    }
}