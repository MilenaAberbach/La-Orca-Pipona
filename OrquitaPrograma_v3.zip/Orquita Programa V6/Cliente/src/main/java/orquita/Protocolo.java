package orquita;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class Protocolo {

    public static final String TIPO_TELEMETRIA = "TLM";
    public static final String TIPO_ORDEN = "ORD";
    public static final String TIPO_EVENTO = "EVT";
    public static final String TIPO_ESTADO = "STA";
    public static final String TIPO_HEARTBEAT = "HB";

    public static class Mensaje {

        public final String tipo;
        public final Map<String, String> campos;
        public final boolean valido;

        Mensaje(String tipo, Map<String, String> campos, boolean valido) {
            this.tipo = tipo;
            this.campos = campos;
            this.valido = valido;
        }

        public String get(String campo) {
            return campos.get(campo);
        }

        public double getDouble(String campo, double porDefecto) {
            try {
                return Double.parseDouble(campos.get(campo));
            } catch (Exception e) {
                return porDefecto;
            }
        }
    }

    public static String construirTelemetria(DatosSensores d) {

        return String.format(
            Locale.US,
            "%s|d60=%.2f;d70=%.2f;d80=%.2f;d90=%.2f;d100=%.2f;"
            + "d110=%.2f;d120=%.2f;ir=%d;ts=%d",
            TIPO_TELEMETRIA,
            d.getDist60(), d.getDist70(), d.getDist80(), d.getDist90(),
            d.getDist100(), d.getDist110(), d.getDist120(),
            d.isInfrarrojoDetecta() ? 1 : 0,
            d.getTimestamp()
        );
    }

    public static String construirEvento(String tipoEvento, String resultado) {

        return String.format(
            Locale.US,
            "%s|tipo=%s;resultado=%s;ts=%d",
            TIPO_EVENTO, tipoEvento, resultado,
            System.currentTimeMillis()
        );
    }

    public static String construirEstado(String estado, String detalle) {

        return String.format(
            Locale.US,
            "%s|estado=%s;detalle=%s",
            TIPO_ESTADO, estado, detalle == null ? "" : detalle
        );
    }

    public static String construirHeartbeat() {

        return String.format(
            Locale.US,
            "%s|ts=%d",
            TIPO_HEARTBEAT, System.currentTimeMillis()
        );
    }

    public static Mensaje interpretar(String linea) {

        if (linea == null) {
            return new Mensaje("DESCONOCIDO", new HashMap<>(), false);
        }

        linea = linea.trim();

        if (linea.isEmpty() || !linea.contains("|")) {
            return new Mensaje("DESCONOCIDO", new HashMap<>(), false);
        }

        int sep = linea.indexOf('|');
        String tipo = linea.substring(0, sep).trim();
        String resto = linea.substring(sep + 1);

        Map<String, String> campos = new HashMap<>();

        if (!resto.isEmpty()) {

            for (String par : resto.split(";")) {

                int igual = par.indexOf('=');

                if (igual <= 0) {
                    continue;
                }

                String clave = par.substring(0, igual).trim();
                String valor = par.substring(igual + 1).trim();
                campos.put(clave, valor);
            }
        }

        boolean tipoConocido =
                TIPO_TELEMETRIA.equals(tipo)
                || TIPO_ORDEN.equals(tipo)
                || TIPO_EVENTO.equals(tipo)
                || TIPO_ESTADO.equals(tipo)
                || TIPO_HEARTBEAT.equals(tipo);

        if (!tipoConocido) {
            return new Mensaje(tipo, campos, false);
        }

        boolean valido = validarCamposObligatorios(tipo, campos);

        return new Mensaje(tipo, campos, valido);
    }

    /** Verifica que cada tipo de mensaje traiga los campos que necesita. */
    private static boolean validarCamposObligatorios(
            String tipo, Map<String, String> campos) {

        switch (tipo) {

            case TIPO_ORDEN:
                return campos.containsKey("accion");

            case TIPO_EVENTO:
                return campos.containsKey("tipo")
                        && campos.containsKey("resultado");

            case TIPO_ESTADO:
                return campos.containsKey("estado");

            case TIPO_TELEMETRIA:
                return campos.containsKey("d60")
                        && campos.containsKey("d120");

            case TIPO_HEARTBEAT:
                return true;

            default:
                return false;
        }
    }
}