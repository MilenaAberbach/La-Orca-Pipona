package servidororquita;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

public class PruebaCliente {

    public static void main(String[] args) {

        try {

            Socket socket = new Socket("localhost", 5001);

            System.out.println("=================================");
            System.out.println("      CLIENTE DE PRUEBA");
            System.out.println("=================================");
            System.out.println("Conectado al ServidorOrquita.");

            BufferedReader entrada =
                    new BufferedReader(
                            new InputStreamReader(
                                    socket.getInputStream()
                            )
                    );

            PrintWriter salida =
                    new PrintWriter(
                            socket.getOutputStream(),
                            true
                    );

            System.out.println();
            System.out.println("Enviando estado...");

            salida.println("EST|BUSCANDO");

            System.out.println("Enviando sensores...");

            salida.println(
                    "TLM"
                    + "|25"
                    + "|28"
                    + "|30"
                    + "|35"
                    + "|40"
                    + "|42"
                    + "|45"
                    + "|25"
                    + "|20"
            );

            String respuesta = entrada.readLine();

            System.out.println();
            System.out.println(
                    "Respuesta del servidor: "
                    + respuesta
            );

            for (int i = 1; i <= 3; i++) {

                System.out.println();
                System.out.println(
                        "Simulando captura de Lobito #"
                        + i
                );

                salida.println("CAPTURA|LOBITO");

                respuesta = entrada.readLine();

                System.out.println(
                        "Respuesta del servidor: "
                        + respuesta
                );

                Thread.sleep(500);
            }

            System.out.println();
            System.out.println("=================================");
            System.out.println("3 capturas enviadas.");
            System.out.println("Esperando MODO ESCAPE...");
            System.out.println("=================================");

            while (true) {

                respuesta = entrada.readLine();

                if (respuesta == null) {
                    System.out.println();
                    System.out.println("El servidor cerró la conexión.");
                    break;
                }

                System.out.println(
                        "[SERVIDOR] "
                        + respuesta
                );

                if (respuesta.equals(
                        Protocolo.orden(Protocolo.ESCAPE)
                )) {

                    System.out.println();
                    System.out.println("=================================");
                    System.out.println("     MODO ESCAPE RECIBIDO");
                    System.out.println("=================================");
                    System.out.println();
                    System.out.println(
                            "La Orquita recibió la orden ESCAPE."
                    );

                    break;
                }
            }

            socket.close();

            System.out.println();
            System.out.println("Cliente desconectado.");

        } catch (Exception e) {

            System.out.println();
            System.out.println("=================================");
            System.out.println("ERROR EN CLIENTE DE PRUEBA");
            System.out.println("=================================");
            System.out.println(e.getMessage());

            e.printStackTrace();
        }
    }
}