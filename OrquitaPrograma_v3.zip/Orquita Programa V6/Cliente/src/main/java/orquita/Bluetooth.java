package orquita;

import com.fazecast.jSerialComm.SerialPort;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;

public class Bluetooth {

    private final String rutaDispositivo;

    private SerialPort puerto;

    private BufferedReader lector;
    private PrintWriter escritor;

    private volatile boolean conectado = false;


    public Bluetooth(String rutaDispositivo) {
        this.rutaDispositivo = rutaDispositivo;
    }


    public synchronized void conectar() throws IOException {

        System.out.println("[BT] Buscando puerto " + rutaDispositivo);

        puerto = SerialPort.getCommPort(rutaDispositivo);

        // 9600 baudios, 8 bits de datos, 1 bit de parada, sin paridad
        puerto.setComPortParameters(
                9600,
                8,
                SerialPort.ONE_STOP_BIT,
                SerialPort.NO_PARITY
        );

        // CORRECCION CLAVE:
        // Lectura bloqueante. Sin esto, read() devuelve -1 cuando no hay datos,
        // readLine() devuelve null y el programa cree que la conexion se cerro.
        puerto.setComPortTimeouts(
                SerialPort.TIMEOUT_READ_BLOCKING | SerialPort.TIMEOUT_WRITE_BLOCKING,
                0,
                0
        );

        if (!puerto.openPort()) {
            throw new IOException(
                    "No se pudo abrir el puerto Bluetooth. "
                    + "Verifica que el HC-05 este emparejado y que ningun otro programa lo use."
            );
        }

        System.out.println("[BT] Puerto abierto.");

        lector = new BufferedReader(
                new InputStreamReader(puerto.getInputStream())
        );

        escritor = new PrintWriter(puerto.getOutputStream(), true);

        conectado = true;

        System.out.println("[BT] Conexion establecida.");
    }


    public boolean isConectado() {
        return conectado;
    }


    public synchronized void enviar(String mensaje) throws IOException {

        if (!conectado || escritor == null) {
            throw new IOException("Bluetooth no conectado.");
        }

        // println agrega el salto de linea que el Arduino necesita para procesar la orden
        escritor.println(mensaje);

        if (escritor.checkError()) {
            conectado = false;
            throw new IOException("Error enviando mensaje.");
        }
    }


    public String recibir() throws IOException {

        if (!conectado || lector == null) {
            throw new IOException("Bluetooth no conectado.");
        }

        String linea = lector.readLine();

        if (linea == null) {
            conectado = false;
        }

        return linea;
    }


    public synchronized void desconectar() {

        conectado = false;

        try {
            // Cerrar el puerto primero desbloquea el readLine() del hilo lector
            if (puerto != null && puerto.isOpen()) {
                puerto.closePort();
            }

            if (lector != null) {
                lector.close();
            }

            if (escritor != null) {
                escritor.close();
            }

        } catch (Exception e) {
            // se ignora al cerrar
        }

        System.out.println("[BT] Desconectado.");
    }

}