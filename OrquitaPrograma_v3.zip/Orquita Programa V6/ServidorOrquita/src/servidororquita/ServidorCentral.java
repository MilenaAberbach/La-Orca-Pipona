package servidororquita;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class ServidorCentral {

    public static final int PUERTO = 5001;

    private ServerSocket serverSocket;
    private volatile boolean ejecutando;

    public void iniciar() {

        try {

            serverSocket = new ServerSocket(PUERTO);
            ejecutando = true;

            System.out.println("======================================");
            System.out.println("       SERVIDOR CENTRAL ORQUITA");
            System.out.println("======================================");
            System.out.println("       SERVIDOR CENTRAL ORQUITA");
            System.out.println("Puerto: " + PUERTO);
            System.out.println("Servidor iniciado.");
            System.out.println("Esperando conexión...");
            System.out.println();

            AuditorEstomago auditor =
                    new AuditorEstomago("estomago.txt");

            Thread hiloAuditor =
                    new Thread(auditor, "AuditorEstomago");

            hiloAuditor.setDaemon(true);
            hiloAuditor.start();

            System.out.println(
                    "[SERVIDOR] Auditor del estómago iniciado."
            );

            while (ejecutando) {

                try {

                    Socket socket =
                            serverSocket.accept();

                    System.out.println();
                    System.out.println(
                            "======================================"
                    );
                    System.out.println(
                            "ORQUITA CONECTADA"
                    );
                    System.out.println(
                            "IP: " + socket.getInetAddress()
                    );
                    System.out.println(
                            "Puerto cliente: " + socket.getPort()
                    );
                    System.out.println(
                            "======================================"
                    );

                    ClienteHandler cliente =
                            new ClienteHandler(socket);

                    Thread hiloCliente =
                            new Thread(
                                    cliente,
                                    "ClienteHandler-"
                                    + socket.getPort()
                            );

                    hiloCliente.start();

                } catch (IOException e) {

                    if (ejecutando) {

                        System.out.println(
                                "[SERVIDOR] Error aceptando cliente: "
                                + e.getMessage()
                        );
                    }
                }
            }

        } catch (IOException e) {

            System.out.println();
            System.out.println("======================================");
            System.out.println("[SERVIDOR] ERROR AL INICIAR");
            System.out.println("======================================");

            System.out.println("Motivo: " + e.getMessage());

            e.printStackTrace();

        } finally {

            detener();
        }
    }

    public void detener() {

        ejecutando = false;

        try {

            if (serverSocket != null
                    && !serverSocket.isClosed()) {

                serverSocket.close();
            }

        } catch (IOException e) {

            System.out.println(
                    "[SERVIDOR] Error al cerrar servidor: "
                    + e.getMessage()
            );
        }

        System.out.println(
                "[SERVIDOR] Servidor detenido."
        );
    }

    public static void main(String[] args) {

        ServidorCentral servidor =
                new ServidorCentral();

        servidor.iniciar();
    }
}