package orquita;

public class Servomg90s {

    private volatile int anguloActual = 90;

    public synchronized void moverA(int grados) {

        if (grados < 0) grados = 0;
        if (grados > 180) grados = 180;

        this.anguloActual = grados;

        System.out.println("[SERVO] Moviendo a " + grados + "°");
    }

    public int getAnguloActual() {
        return anguloActual;
    }

    public void posicionSegura() {
        moverA(90);
    }
}