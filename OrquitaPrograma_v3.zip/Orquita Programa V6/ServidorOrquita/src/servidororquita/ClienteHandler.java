package servidororquita;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.time.LocalDateTime;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

public class ClienteHandler implements Runnable {

    private static final List<ClienteHandler> ACTIVOS =
            new CopyOnWriteArrayList<>();

    private final Socket socket;
    private BufferedReader entrada;
    private PrintWriter salida;
    private RedNeuronalOrquita red;

    public ClienteHandler(Socket socket) {

        this.socket = socket;

        try {
            red = new RedNeuronalOrquita(
                    "/Users/claudiomartyniuk/Downloads/Orquita Programa V4/red_orquita.nnet"
            );

            System.out.println(
                    "[NEUROPH] Red neuronal cargada correctamente."
            );

        } catch (Exception e) {

            System.out.println(
                    "[NEUROPH] ERROR cargando red neuronal: "
                    + e.getMessage()
            );

            red = null;
        }
    }

    @Override
    public void run() {

        ACTIVOS.add(this);

        try {

            entrada = new BufferedReader(
                    new InputStreamReader(
                            socket.getInputStream()
                    )
            );

            salida = new PrintWriter(
                    socket.getOutputStream(),
                    true
            );

            System.out.println(
                    "[CLIENTE HANDLER] Hilo iniciado."
            );

            System.out.println(
                    "[CLIENTE HANDLER] Esperando mensajes..."
            );

            String mensaje;

            while ((mensaje = entrada.readLine()) != null) {

                mensaje = mensaje.trim();

                if (mensaje.isEmpty()) {
                    continue;
                }

                System.out.println();
                System.out.println(
                        "[RECIBIDO] " + mensaje
                );

                procesarMensaje(mensaje);
            }

            System.out.println(
                    "[CLIENTE HANDLER] Cliente cerró la conexión."
            );

        } catch (IOException e) {

            System.out.println(
                    "[CLIENTE HANDLER] Conexión con Orquita perdida."
            );

            System.out.println(
                    "[CLIENTE HANDLER] " + e.getMessage()
            );

        } finally {

            ACTIVOS.remove(this);
            cerrarConexion();
        }
    }

    public static void notificarEscapeATodos() {

        String orden =
                Protocolo.orden(
                        Protocolo.ESCAPE
                );

        System.out.println(
                "[NOTIFICACION] Difundiendo Modo Escape a "
                + ACTIVOS.size()
                + " conexión(es) activa(s)."
        );

        for (ClienteHandler ch : ACTIVOS) {
            ch.enviar(orden);
        }
    }

    public static void enviarComandoATodos(
            String accion) {

        String mensaje =
                Protocolo.orden(accion);

        for (ClienteHandler cliente : ACTIVOS) {

            try {

                cliente.salida.println(mensaje);

            } catch (Exception e) {

                System.out.println(
                        "[SERVIDOR] Error enviando comando: "
                        + e.getMessage()
                );
            }
        }
    }

    private void procesarMensaje(String mensaje) {

        if (!Protocolo.esMensajeValido(mensaje)) {

            System.out.println(
                    "[PROTOCOLO] Mensaje inválido."
            );

            enviarOrden(Protocolo.DETENER);
            return;
        }

        if (mensaje.startsWith(
                Protocolo.TLM + "|")) {

            procesarSensores(mensaje);
            return;
        }

        if (mensaje.startsWith(
                Protocolo.CAPTURA + "|")) {

            procesarCaptura(mensaje);
            return;
        }

        if (mensaje.startsWith(
                Protocolo.EST + "|")) {

            procesarEstado(mensaje);
            return;
        }

        if (mensaje.equals(
                Protocolo.HEARTBEAT)) {

            System.out.println(
                    "[HEARTBEAT] Recibido."
            );

            enviar(
                    Protocolo.ack(
                            Protocolo.HEARTBEAT
                    )
            );

            return;
        }

        if (mensaje.startsWith(
                Protocolo.ACK + "|")) {

            System.out.println(
                    "[ACK] Recibido: " + mensaje
            );

            return;
        }

        System.out.println(
                "[PROTOCOLO] Tipo de mensaje no reconocido."
        );
    }

    private void procesarSensores(String mensaje) {

        try {

            double[] sensores =
                    extraerSensores(mensaje);

            if (sensores == null) {

                System.out.println(
                        "[SENSORES] Vector inválido."
                );

                enviarOrden(
                        Protocolo.DETENER
                );

                return;
            }

            System.out.println(
                    "[SENSORES] Vector recibido:"
            );

            for (int i = 0;
                    i < sensores.length;
                    i++) {

                System.out.println(
                        "  Sensor[" + i + "] = "
                        + sensores[i]
                );
            }

            if (red == null) {

                System.out.println(
                        "[NEUROPH] Red no disponible."
                );

                enviarOrden(
                        Protocolo.DETENER
                );

                return;
            }

            double clasificacion =
                    red.clasificar(sensores);

            String resultado;

            if (clasificacion >= 0.5) {
                resultado = "LOBITO";
            } else {
                resultado = "OBSTÁCULO";
            }

            System.out.println(
                    "[NEUROPH] Clasificación: "
                    + clasificacion
                    + " -> "
                    + resultado
            );

            String orden =
                    Navegacion.decidir(
                            clasificacion,
                            sensores
                    );

            if (orden == null
                    || orden.trim().isEmpty()) {

                System.out.println(
                        "[NAVEGACION] No se generó una orden."
                );

                enviarOrden(
                        Protocolo.DETENER
                );

                return;
            }

            orden = orden.trim();

            System.out.println(
                    "[NAVEGACION] Orden generada: "
                    + orden
            );

            if (!orden.startsWith(
                    Protocolo.ORD + "|")) {

                System.out.println(
                        "[NAVEGACION] Orden inválida: "
                        + orden
                );

                enviarOrden(
                        Protocolo.DETENER
                );

                return;
            }

            enviar(orden);

        } catch (Exception e) {

            System.out.println(
                    "[SENSORES] Error procesando sensores:"
            );

            System.out.println(
                    "[SENSORES] " + e.getMessage()
            );

            e.printStackTrace();

            enviarOrden(
                    Protocolo.DETENER
            );
        }
    }

    private double[] extraerSensores(
            String mensaje) {

        try {

            String[] partes =
                    mensaje.split("\\|");

            if (partes.length != 10) {

                System.out.println(
                        "[SENSORES] ERROR: se esperaban 9 valores."
                );

                System.out.println(
                        "[SENSORES] Partes recibidas: "
                        + partes.length
                );

                return null;
            }

            double[] sensores =
                    new double[9];

            for (int i = 1;
                    i < partes.length;
                    i++) {

                String valor =
                        partes[i].trim();

                if (valor.isEmpty()) {
                    return null;
                }

                sensores[i - 1] =
                        Double.parseDouble(valor);
            }

            for (double valor : sensores) {

                if (Double.isNaN(valor)
                        || Double.isInfinite(valor)) {

                    System.out.println(
                            "[SENSORES] Valor inválido."
                    );

                    return null;
                }

                if (valor < 0) {

                    System.out.println(
                            "[SENSORES] Valor negativo."
                    );

                    return null;
                }
            }

            return sensores;

        } catch (NumberFormatException e) {

            System.out.println(
                    "[SENSORES] ERROR: valor no numérico."
            );

            return null;
        }
    }

    private void procesarCaptura(
            String mensaje) {

        try {

            String[] partes =
                    mensaje.split("\\|");

            if (partes.length != 2) {

                System.out.println(
                        "[CAPTURA] Mensaje incompleto."
                );

                return;
            }

            String objetivo =
                    partes[1].trim();

            System.out.println(
                    "[CAPTURA] Objetivo recibido: "
                    + objetivo
            );

            if (objetivo.equalsIgnoreCase(
                    "LOBITO")) {

                String registro =
                        "LOBITO|"
                        + LocalDateTime.now();

                PersistenciaEstomago
                        .registrarCaptura(registro);

                System.out.println(
                        "[CAPTURA] LOBITO registrado."
                );

                enviar(
                        Protocolo.ack(
                                "CAPTURA"
                        )
                );

                return;
            }

            System.out.println(
                    "[CAPTURA] Objetivo desconocido: "
                    + objetivo
            );

        } catch (Exception e) {

            System.out.println(
                    "[CAPTURA] Error procesando captura: "
                    + e.getMessage()
            );
        }
    }

    private void procesarEstado(
            String mensaje) {

        System.out.println(
                "[ESTADO] Estado de Orquita:"
        );

        System.out.println(mensaje);
    }

    private void enviarOrden(
            String accion) {

        if (accion == null
                || accion.trim().isEmpty()) {

            accion = Protocolo.DETENER;
        }

        accion =
                accion.trim().toUpperCase();

        if (!Protocolo.esAccionValida(
                accion)) {

            System.out.println(
                    "[ORDEN] Acción inválida: "
                    + accion
            );

            accion = Protocolo.DETENER;
        }

        String mensaje =
                Protocolo.orden(accion);

        enviar(mensaje);
    }

    public synchronized void enviar(
            String mensaje) {

        if (salida == null) {

            System.out.println(
                    "[ENVIO] No existe conexión de salida."
            );

            return;
        }

        if (mensaje == null
                || mensaje.trim().isEmpty()) {

            System.out.println(
                    "[ENVIO] Mensaje vacío."
            );

            return;
        }

        try {

            salida.println(mensaje);

            if (salida.checkError()) {

                System.out.println(
                        "[ENVIO] Error enviando mensaje."
                );

                return;
            }

            System.out.println(
                    "[ENVIANDO] " + mensaje
            );

        } catch (Exception e) {

            System.out.println(
                    "[ENVIO] Error: "
                    + e.getMessage()
            );
        }
    }

    private void cerrarConexion() {

        try {

            if (entrada != null) {
                entrada.close();
            }

            if (salida != null) {
                salida.close();
            }

            if (socket != null
                    && !socket.isClosed()) {

                socket.close();
            }

        } catch (IOException e) {

            System.out.println(
                    "[CONEXION] Error cerrando conexión: "
                    + e.getMessage()
            );
        }

        System.out.println(
                "[CONEXION] Cliente desconectado."
        );
    }
}