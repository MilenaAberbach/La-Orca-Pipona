package servidororquita;

public class Servidor {

    private static final double DISTANCIA_MINIMA = 2.0;
    private static final double DISTANCIA_MAXIMA = 400.0;

    private int contadorCapturas = 0;
    private String modoActual = "SEGURO";

    public Servidor() {

        modoActual = "SEGURO";

        System.out.println(
                "[SERVIDOR ORQUITA] Iniciado en modo SEGURO."
        );
    }

    public boolean verificarValores(double sensor) {

        if (Double.isNaN(sensor)
                || Double.isInfinite(sensor)) {

            return false;
        }

        return sensor >= DISTANCIA_MINIMA
                && sensor <= DISTANCIA_MAXIMA;
    }

    public void enviarComando(String modo) {

        if (modo == null
                || modo.trim().isEmpty()) {

            return;
        }

        modo = modo.trim().toUpperCase();

        switch (modo) {

            case "AVANZAR":
            case "RETROCEDER":
            case "IZQUIERDA":
            case "DERECHA":
            case "DETENER":
            case "CAPTURAR":
            case "ESCAPE":

                ClienteHandler.enviarComandoATodos(modo);

                System.out.println(
                        "[SERVIDOR ORQUITA] Comando enviado: "
                        + modo
                );

                break;

            default:

                System.out.println(
                        "[SERVIDOR ORQUITA] Comando inválido: "
                        + modo
                );
        }
    }

    public void activarModo(String modo) {

        if (modo == null
                || modo.trim().isEmpty()) {

            return;
        }

        modo = modo.trim().toUpperCase();

        switch (modo) {

            case "BUSQUEDA":

                activarModoBusqueda();
                break;

            case "APROXIMACION":

                activarModoAproximacion();
                break;

            case "CAPTURA":

                activarModoCaptura();
                break;

            case "ESCAPE":

                activarModoEscape();
                break;

            case "FINALIZACION":

                activarModoFinalizacion();
                break;

            case "SEGURO":

                activarModoSeguro();
                break;

            default:

                System.out.println(
                        "[SERVIDOR ORQUITA] Modo desconocido: "
                        + modo
                );
        }
    }

    public void notificarEleIdentificado() {

        System.out.println(
                "[SERVIDOR ORQUITA] Elemento identificado."
        );

        activarModoAproximacion();
    }

    public void activarModoBusqueda() {

        modoActual = "BUSQUEDA";

        System.out.println(
                "[MODO] BUSQUEDA"
        );

        enviarComando("AVANZAR");
    }

    public void activarModoAproximacion() {

        modoActual = "APROXIMACION";

        System.out.println(
                "[MODO] APROXIMACION"
        );

        enviarComando("AVANZAR");
    }

    public void activarModoCaptura() {

        modoActual = "CAPTURA";

        System.out.println(
                "[MODO] CAPTURA"
        );

        enviarComando("CAPTURAR");
    }

    public void activarModoEscape() {

        modoActual = "ESCAPE";

        System.out.println(
                "[MODO] ESCAPE"
        );

        enviarComando("ESCAPE");
    }

    public void activarModoFinalizacion() {

        modoActual = "FINALIZACION";

        System.out.println(
                "[MODO] FINALIZACION"
        );

        enviarComando("DETENER");
    }

    public void activarModoSeguro() {

        modoActual = "SEGURO";

        System.out.println(
                "[MODO] SEGURO"
        );

        enviarComando("DETENER");
    }

    public synchronized void registrarCapturaLobito() {

        PersistenciaEstomago.registrarCaptura(
                "LOBITO"
        );

        incrementarContador(1);

        System.out.println(
                "[CAPTURA] Lobito registrado."
        );
    }

    public synchronized void incrementarContador(int c) {

        if (c <= 0) {
            return;
        }

        contadorCapturas += c;

        System.out.println(
                "[CONTADOR] Capturas: "
                + contadorCapturas
        );

        if (contadorCapturas >= 3) {

            activarModoEscape();
        }
    }

    public synchronized String getModoActual() {

        return modoActual;
    }

    public synchronized int getContadorCapturas() {

        return contadorCapturas;
    }
}
