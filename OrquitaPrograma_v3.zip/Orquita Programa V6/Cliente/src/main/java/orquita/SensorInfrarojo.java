package orquita;

import java.util.Random;

public class SensorInfrarojo {

    private final Random random = new Random();

    public boolean detecta() {

        return random.nextDouble() < 0.15;
    }
}