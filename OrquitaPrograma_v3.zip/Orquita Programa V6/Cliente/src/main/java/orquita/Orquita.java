
package orquita;

public class Orquita {

    private ArduinoSerial arduino;
    private Cliente cliente;

    public Orquita(ArduinoSerial arduino, Cliente cliente) {
        this.arduino = arduino;
        this.cliente = cliente;
    }

    public double capturarDistancia(String objeto, int sensor) {

        if (arduino == null) {
            System.out.println("[ORQUITA] Arduino no conectado.");
            return -1;
        }

        if (sensor < 0 || sensor >= 7) {
            System.out.println("[ORQUITA] Sensor inválido.");
            return -1;
        }

        try {

            double[] distancias = arduino.esperarBarrido(3000, 0);

            if (distancias == null || distancias.length <= sensor) {
                System.out.println("[ORQUITA] No se recibió un barrido válido.");
                return -1;
            }

            double distancia = distancias[sensor];

            if (Double.isNaN(distancia)
                    || Double.isInfinite(distancia)
                    || distancia < 0) {

                System.out.println("[ORQUITA] Distancia inválida.");
                return -1;
            }

            System.out.println(
                    "[ORQUITA] Objeto: " + objeto
                    + " | Sensor: " + sensor
                    + " | Distancia: " + distancia + " cm"
            );

            return distancia;

        } catch (Exception e) {

            System.out.println(
                    "[ORQUITA] Error leyendo sensor: "
                    + e.getMessage()
            );

            return -1;
        }
    }

    public void enviarComando(String modo) {

        if (cliente == null) {
            System.out.println("[ORQUITA] Cliente no disponible.");
            return;
        }

        if (modo == null || modo.trim().isEmpty()) {
            System.out.println("[ORQUITA] Comando vacío.");
            return;
        }

        cliente.enviarComando(modo.trim().toUpperCase());
    }

    public void ejecutarMovimiento(String modo) {

        if (modo == null || modo.trim().isEmpty()) {
            System.out.println("[ORQUITA] Movimiento vacío.");
            return;
        }

        modo = modo.trim().toUpperCase();

        switch (modo) {

            case "AVANZAR":
                enviarComando("AVANZAR");
                break;

            case "RETROCEDER":
                enviarComando("RETROCEDER");
                break;

            case "IZQUIERDA":
                enviarComando("IZQUIERDA");
                break;

            case "DERECHA":
                enviarComando("DERECHA");
                break;

            case "DETENER":
                enviarComando("DETENER");
                break;

            case "CAPTURAR":
                capturarLobito();
                break;

            case "ESCAPE":
                enviarComando("ESCAPE");
                break;

            default:
                System.out.println(
                        "[ORQUITA] Movimiento desconocido: " + modo
                );
                enviarComando("DETENER");
                break;
        }
    }

    public void activarMotores() {

        if (cliente == null) {
            System.out.println("[ORQUITA] Cliente no disponible.");
            return;
        }

        System.out.println("[ORQUITA] Activando motores.");

        cliente.enviarComando("AVANZAR");
    }

    public void capturarLobito() {

        if (cliente == null) {
            System.out.println("[ORQUITA] Cliente no disponible.");
            return;
        }

        System.out.println("[ORQUITA] Iniciando captura del Lobito.");

        cliente.enviarComando("CAPTURAR");
    }
}
