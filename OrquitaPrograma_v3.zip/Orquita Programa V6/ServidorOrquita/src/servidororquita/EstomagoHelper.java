package servidororquita;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

public class EstomagoHelper {

    public List<String> leerRegistros(String archivo) {

        List<String> registros = new ArrayList<String>();

        try {

            BufferedReader lector =
                    new BufferedReader(new FileReader(archivo));

            String linea;

            while ((linea = lector.readLine()) != null) {

                linea = linea.trim();

                if (!linea.isEmpty()) {
                    registros.add(linea);
                }
            }

            lector.close();

        } catch (IOException e) {

            System.out.println(
                    "[ESTOMAGO] Error leyendo registros: "
                    + e.getMessage()
            );
        }

        return registros;
    }

    public void escribirCaptura(String archivo, String registro) {

        if (registro == null || registro.trim().isEmpty()) {
            return;
        }

        try {

            PrintWriter escritor =
                    new PrintWriter(
                            new FileWriter(archivo, true)
                    );

            escritor.println(registro);
            escritor.close();

            System.out.println(
                    "[ESTOMAGO] Captura registrada: "
                    + registro
            );

        } catch (IOException e) {

            System.out.println(
                    "[ESTOMAGO] Error escribiendo captura: "
                    + e.getMessage()
            );
        }
    }
}