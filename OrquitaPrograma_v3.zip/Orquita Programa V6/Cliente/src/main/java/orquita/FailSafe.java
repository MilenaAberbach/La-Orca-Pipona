package orquita;

public class FailSafe implements Runnable {

    private static final long TIMEOUT_MS = 5000;
    private static final long INTERVALO_CHEQUEO_MS = 1000;

    private final Servomg90s servo;
    private volatile long ultimaActividad;
    private volatile boolean enFailSafe = false;
    private volatile boolean activo = true;

    public FailSafe(Servomg90s servo) {
        this.servo = servo;
        this.ultimaActividad = System.currentTimeMillis();
    }

    public void marcarActividad() {

        ultimaActividad = System.currentTimeMillis();

        if (enFailSafe) {

            enFailSafe = false;

            System.out.println(
                "[FAIL-SAFE] Comunicación restablecida. "
                + "Saliendo de estado seguro."
            );
        }
    }

    public boolean isEnFailSafe() {
        return enFailSafe;
    }

    public void detener() {
        activo = false;
    }

    @Override
    public void run() {

        while (activo) {

            long inactivo = System.currentTimeMillis() - ultimaActividad;

            if (!enFailSafe && inactivo > TIMEOUT_MS) {
                activar();
            }

            try {
                Thread.sleep(INTERVALO_CHEQUEO_MS);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                return;
            }
        }
    }

    private void activar() {

        enFailSafe = true;

        System.out.println();
        System.out.println("==========================================");
        System.out.println("  [FAIL-SAFE] PÉRDIDA DE COMUNICACIÓN");
        System.out.println("  Deteniendo la Orquita en estado seguro.");
        System.out.println("==========================================");

        servo.posicionSegura();
    }
}