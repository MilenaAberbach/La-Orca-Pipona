package servidororquita;

import java.util.List;

public class AuditorEstomago implements Runnable {

    private static final int UMBRAL_CAPTURAS = 3;
    private static final long INTERVALO_POLLING_MS = 1000;

    private volatile boolean ejecutando = true;
    private volatile boolean escapeActivado = false;

    private final EstomagoHelper estomagoHelper;
    private final String archivo;

    public AuditorEstomago(String archivo) {
        this.archivo = archivo;
        this.estomagoHelper = new EstomagoHelper();
    }

    @Override
    public void run() {

        System.out.println("[AUDITOR] Hilo auditor iniciado.");

        while (ejecutando) {

            try {

                List<String> registros =
                        estomagoHelper.leerRegistros(archivo);

                int capturas = contarCapturas(registros);

                System.out.println("[AUDITOR] Capturas: " + capturas);

                if (capturas >= UMBRAL_CAPTURAS && !escapeActivado) {

                    escapeActivado = true;
                    activarModoEscape();
                }

                Thread.sleep(INTERVALO_POLLING_MS);

            } catch (InterruptedException e) {

                Thread.currentThread().interrupt();
                ejecutando = false;
            }
        }
    }

    private int contarCapturas(List<String> registros) {

        int contador = 0;

        for (String registro : registros) {

            if (registro.startsWith("LOBITO|")) {
                contador++;
            }
        }

        return contador;
    }

    private void activarModoEscape() {

        System.out.println();
        System.out.println("======================================");
        System.out.println("   " + UMBRAL_CAPTURAS + " CAPTURAS ALCANZADAS");
        System.out.println("   MODO ESCAPE ACTIVADO");
        System.out.println("======================================");

        ClienteHandler.notificarEscapeATodos();
    }

    public void detener() {
        ejecutando = false;
    }

    public boolean isEscapeActivado() {
        return escapeActivado;
    }
}