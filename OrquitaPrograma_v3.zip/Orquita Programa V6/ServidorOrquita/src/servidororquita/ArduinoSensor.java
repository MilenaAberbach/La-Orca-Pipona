package servidororquita;

import com.fazecast.jSerialComm.SerialPort;
import java.util.Scanner;

public class ArduinoSensor {

    private SerialPort puerto;

    public ArduinoSensor(String puertoCOM) {

        puerto = SerialPort.getCommPort(puertoCOM);
        puerto.setBaudRate(9600);

        if (puerto.openPort()) {
            System.out.println("Arduino conectado en " + puertoCOM);
        } else {
            System.out.println("No se pudo conectar Arduino");
        }
    }


    public double leerDistancia() {

        Scanner entrada = new Scanner(puerto.getInputStream());

        if (entrada.hasNextLine()) {

            String dato = entrada.nextLine();

            return Double.parseDouble(dato);
        }

        return -1;
    }
}