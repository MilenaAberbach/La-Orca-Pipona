package orquita;

import com.fazecast.jSerialComm.SerialPort;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

public class Cliente {

    private static final String HOST = "127.0.0.1";
    private static final int PUERTO = 5001;

    private static final int PERIODO_LECTURA_MS = 500;
    private static final int[] ANGULOS =
            {60, 70, 80, 90, 100, 110, 120};

    private static final long TIMEOUT_FAILSAFE_MS = 30000;

    private Socket socket;
    private BufferedReader entrada;
    private PrintWriter salida;
    private ArduinoSerial arduino;

    private volatile boolean corriendo = true;

    private volatile long ultimaActividad =
            System.currentTimeMillis();

    private volatile boolean failSafeActivo = false;

    private int posicionServo = 90;
    
    // Valor que se usa cuando una posición no devuelve eco (el Arduino ya reintentó 3 veces)
    private static final double SIN_ECO_CM = 300.0;
    private static final long ESPERA_BARRIDO_MS = 15000;
    // 0 = usa el próximo barrido que llegue. 1 = descarta uno (más lento, datos más frescos)
    private static final int BARRIDOS_A_DESCARTAR = 0;    

    public static void main(String[] args) {

        System.out.println(
                "=========================================="
        );

        System.out.println(
                "             CLIENTE ORQUITA"
        );

        System.out.println(
                "=========================================="
        );

        Cliente cliente = new Cliente();

        try {

            cliente.iniciar();

        } catch (Exception e) {

            System.out.println();
            System.out.println(
                    "=========================================="
            );

            System.out.println(
                    "          ERROR DEL CLIENTE"
            );

            System.out.println(
                    "=========================================="
            );

            System.out.println(
                    "[ERROR] " + e.getMessage()
            );

            e.printStackTrace();

        } finally {

            cliente.detener();
        }
    }

    public void iniciar() throws IOException {
        System.out.println("[CLIENTE] Conectando con el Servidor Central...");

        conectarTCP();

        System.out.println("[CLIENTE] Conectado correctamente.");
        System.out.println("\n===== PUERTOS SERIALES DETECTADOS =====");
        SerialPort[] puertos = SerialPort.getCommPorts();

        for (SerialPort p : puertos) {
            System.out.println(
                "Nombre: " + p.getSystemPortName()
                + " | Ruta: " + p.getSystemPortPath()
                + " | Descripción: " + p.getDescriptivePortName()
            );
        }
        System.out.println("=======================================\n");

        // Inicializa comunicación con Arduino UNO
        arduino = new ArduinoSerial("/dev/cu.HC-05");

        System.out.println(
                "[CLIENTE] Servidor: "
                + HOST
                + ":"
                + PUERTO
        );

        System.out.println("[CLIENTE] Iniciando Orquita...");

        enviar("EST|BUSCANDO");

        Thread receptor =
                new Thread(this::loopReceptor,"Receptor");

        receptor.setDaemon(true);
        receptor.start();


        Thread failSafe =
                new Thread(this::loopFailSafe,"FailSafe");

        failSafe.setDaemon(true);
        failSafe.start();



        loopSensado();


        desconectarTCP();
    }

    private void conectarTCP()
            throws IOException {

        System.out.println(
                "[TCP] Conectando a "
                + HOST
                + ":"
                + PUERTO
        );

        socket =
                new Socket(
                        HOST,
                        PUERTO
                );

        entrada =
                new BufferedReader(
                        new InputStreamReader(
                                socket.getInputStream()
                        )
                );

        salida =
                new PrintWriter(
                        socket.getOutputStream(),
                        true
                );

        ultimaActividad =
                System.currentTimeMillis();

        System.out.println(
                "[TCP] Conexión establecida."
        );
    }

    private synchronized void desconectarTCP() {

        try {

            if (entrada != null) {
                entrada.close();
            }

            if (salida != null) {
                salida.close();
            }

            if (socket != null
                    && !socket.isClosed()) {

                socket.close();
            }

        } catch (IOException e) {

            System.out.println(
                    "[TCP] Error cerrando conexión: "
                    + e.getMessage()
            );
        }

        entrada = null;
        salida = null;
        socket = null;
    }

    private synchronized void enviar(
            String mensaje)
            throws IOException {

        if (salida == null) {

            throw new IOException(
                    "TCP no conectado."
            );
        }

        if (mensaje == null
                || mensaje.trim().isEmpty()) {

            throw new IOException(
                    "Mensaje vacío."
            );
        }

        salida.println(mensaje);

        if (salida.checkError()) {

            throw new IOException(
                    "Error enviando mensaje TCP."
            );
        }

        ultimaActividad =
                System.currentTimeMillis();

        System.out.println(
                "[ENVIANDO] "
                + mensaje
        );
    }

    private String recibir()
            throws IOException {

        if (entrada == null) {

            throw new IOException(
                    "TCP no conectado."
            );
        }

        return entrada.readLine();
    }

    private void loopSensado() {
        while (corriendo) {

            if (failSafeActivo) {

                dormir(PERIODO_LECTURA_MS);

                continue;
            }

            System.out.println(
                    "[SENSADO] Iniciando lectura..."
            );

            DatosSensores datos =
                    tomarLectura();

            // Capturas confirmadas por el sensor IR (canica comida)
            int capturas = arduino.consumirCapturas();

            for (int i = 0; i < capturas; i++) {

                try {

                    enviar(construirEventoCaptura());

                    System.out.println(
                            "[CAPTURA] Lobito comido, evento enviado."
                    );

                } catch (IOException e) {

                    System.out.println(
                            "[CAPTURA] Error enviando evento: "
                            + e.getMessage()
                    );
                }
            }

            if (!datos.esValido()) {

                System.out.println(
                        "[SENSADO] Lectura inválida."
                );

                dormir(PERIODO_LECTURA_MS);

                continue;
            }

            try {

                String telemetria =
                        construirTelemetria(datos);

                System.out.println(
                        "[SENSADO] Telemetría: "
                        + telemetria
                );

                enviar(telemetria);

            } catch (IOException e) {

                System.out.println(
                        "[SENSADO] Error enviando: "
                        + e.getMessage()
                );

                corriendo = false;

                break;
            }

            dormir(PERIODO_LECTURA_MS);
        }
    }

    private DatosSensores tomarLectura() {

        double[] d = arduino.esperarBarrido(ESPERA_BARRIDO_MS, BARRIDOS_A_DESCARTAR);

        if (d == null) {
            System.out.println("[SENSADO] No llegó el barrido del Arduino a tiempo.");
            double n = Double.NaN;
            return new DatosSensores(n, n, n, n, n, n, n, false);   // esValido() da false
        }

        for (int i = 0; i < d.length; i++) {
            if (d[i] < 0) {
                d[i] = SIN_ECO_CM;
            }
        }

        System.out.println("[SENSADO] Barrido recibido (izq -> der): "
                + java.util.Arrays.toString(d));

        return new DatosSensores(d[0], d[1], d[2], d[3], d[4], d[5], d[6], false);
    }
    
    private String clasificar(double distancia) {
        if (distancia < 10) {
            return "LOBITO";
        }

        if (distancia < 25) {
            return "OBSTACULO";
        }

        return "LIBRE";
    }

    private void moverServo(int angulo) {

        posicionServo =
                angulo;

        System.out.println(
                "[SERVO] Posición: "
                + angulo
                + "°"
        );
    }

    private void posicionSegura() {

        moverServo(90);
    }

    private static class DatosSensores {

        double d60;
        double d70;
        double d80;
        double d90;
        double d100;
        double d110;
        double d120;

        boolean ir;

        DatosSensores(
                double d60,
                double d70,
                double d80,
                double d90,
                double d100,
                double d110,
                double d120,
                boolean ir) {

            this.d60 = d60;
            this.d70 = d70;
            this.d80 = d80;
            this.d90 = d90;
            this.d100 = d100;
            this.d110 = d110;
            this.d120 = d120;
            this.ir = ir;
        }

        boolean esValido() {

            return !Double.isNaN(d60)
                    && !Double.isInfinite(d60)
                    && !Double.isNaN(d70)
                    && !Double.isInfinite(d70)
                    && !Double.isNaN(d80)
                    && !Double.isInfinite(d80)
                    && !Double.isNaN(d90)
                    && !Double.isInfinite(d90)
                    && !Double.isNaN(d100)
                    && !Double.isInfinite(d100)
                    && !Double.isNaN(d110)
                    && !Double.isInfinite(d110)
                    && !Double.isNaN(d120)
                    && !Double.isInfinite(d120)

                    && d60 >= 0
                    && d70 >= 0
                    && d80 >= 0
                    && d90 >= 0
                    && d100 >= 0
                    && d110 >= 0
                    && d120 >= 0;
        }
    }

    private String construirTelemetria(
            DatosSensores d) {

        double[] distancias = {

            d.d60,
            d.d70,
            d.d80,
            d.d90,
            d.d100,
            d.d110,
            d.d120
        };

        double distMin =
                distancias[0];

        for (int i = 1;
                i < distancias.length;
                i++) {

            if (distancias[i] < distMin) {

                distMin =
                        distancias[i];
            }
        }

        double distMax =
                distancias[0];

        for (int i = 1;
                i < distancias.length;
                i++) {

            if (distancias[i] > distMax) {

                distMax =
                        distancias[i];
            }
        }

        double variacion =
                distMax - distMin;

        return "TLM"
                + "|" + d.d60
                + "|" + d.d70
                + "|" + d.d80
                + "|" + d.d90
                + "|" + d.d100
                + "|" + d.d110
                + "|" + d.d120
                + "|" + distMin
                + "|" + variacion;
    }

    private void loopReceptor() {

        while (corriendo) {

            try {

                String linea =
                        recibir();

                if (linea == null) {

                    System.out.println(
                            "[RECEPTOR] Conexión cerrada."
                    );

                    corriendo = false;

                    break;
                }

                if (linea.trim().isEmpty()) {
                    continue;
                }

                System.out.println(
                        "[RECIBIDO] "
                        + linea
                );

                ultimaActividad =
                        System.currentTimeMillis();

                procesarMensaje(linea);

            } catch (IOException e) {

                if (corriendo) {

                    System.out.println(
                            "[RECEPTOR] Error: "
                            + e.getMessage()
                    );
                }

                corriendo = false;
            }
        }
    }

    private void procesarMensaje(
            String mensaje) {

        if (mensaje.startsWith("ORD|")) {

            procesarOrden(mensaje);

            return;
        }

        if (mensaje.startsWith("EST|")) {

            System.out.println(
                    "[SERVIDOR] "
                    + mensaje
            );

            return;
        }

        if (mensaje.startsWith("HEARTBEAT")) {

            System.out.println(
                    "[SERVIDOR] HEARTBEAT"
            );

            return;
        }

        if (mensaje.startsWith("ACK|")) {

            System.out.println(
                    "[SERVIDOR] ACK recibido: "
                    + mensaje
            );

            return;
        }

        System.out.println(
                "[RECEPTOR] Mensaje desconocido: "
                + mensaje
        );
    }

    private void procesarOrden(String orden) {

        System.out.println("[RECIBIDO] " + orden);

        // IMPORTANTE: reenviar al Arduino el texto completo, ej. "ORD|accion=AVANZAR"
        arduino.enviar(orden);

        String accion = orden.substring(orden.indexOf("=") + 1).trim();
        System.out.println("[ORDEN] " + accion);

        switch (accion) {
            case "AVANZAR":
                System.out.println("[MOTOR] AVANZANDO");
                break;
            case "RETROCEDER":
                System.out.println("[MOTOR] RETROCEDIENDO");
                break;
            case "IZQUIERDA":
                System.out.println("[MOTOR] GIRANDO IZQUIERDA");
                break;
            case "DERECHA":
                System.out.println("[MOTOR] GIRANDO DERECHA");
                break;
            case "DETENER":
                System.out.println("[MOTOR] DETENIENDO");
                break;
            case "CAPTURAR":
                System.out.println("[CAPTURA] INICIANDO CAPTURA");
                break;
            default:
                System.out.println("[ORDEN] Desconocida: " + accion);
        }
    }

    private String obtenerParametro(
            String mensaje,
            String parametro) {

        String[] partes =
                mensaje.split("\\|");

        for (String parte : partes) {

            if (parte.startsWith(
                    parametro + "=")) {

                return parte.substring(
                        parametro.length() + 1
                );
            }
        }

        return null;
    }

    private void activarModoEscape() {

        System.out.println(
                "=========================================="
        );

        System.out.println(
                "          MODO ESCAPE ACTIVADO"
        );

        System.out.println(
                "=========================================="
        );

        detenerMotores();

        System.out.println(
                "[ESCAPE] La Orquita recibió la orden ESCAPE."
        );

        corriendo = false;
    }

    private void avanzar() {

        System.out.println(
                "[MOTOR] AVANZANDO"
        );
    }

    private void retroceder() {

        System.out.println(
                "[MOTOR] RETROCEDIENDO"
        );
    }

    private void girarIzquierda() {

        System.out.println(
                "[MOTOR] GIRANDO IZQUIERDA"
        );
    }

    private void girarDerecha() {

        System.out.println(
                "[MOTOR] GIRANDO DERECHA"
        );
    }

    private void detenerMotores() {

        System.out.println(
                "[MOTOR] DETENIENDO"
        );

        posicionSegura();
    }

    private void capturar() {

        System.out.println(
                "=========================================="
        );

        System.out.println(
                "[CAPTURA] INICIANDO CAPTURA"
        );

        System.out.println(
                "=========================================="
        );

        moverServo(0);

        dormir(500);

        moverServo(90);

        try {

            String evento =
                    construirEventoCaptura();

            enviar(evento);

            System.out.println(
                    "[CAPTURA] Evento enviado."
            );

        } catch (IOException e) {

            System.out.println(
                    "[CAPTURA] Error enviando evento: "
                    + e.getMessage()
            );
        }
    }

    private String construirEventoCaptura() {

        return "CAPTURA|LOBITO";
    }

    private void loopFailSafe() {

        while (corriendo) {

            long ahora =
                    System.currentTimeMillis();

            long diferencia =
                    ahora - ultimaActividad;

            if (diferencia >
                    TIMEOUT_FAILSAFE_MS) {

                if (!failSafeActivo) {

                    activarFailSafe();
                }

            } else {

                if (failSafeActivo) {

                    desactivarFailSafe();
                }
            }

            dormir(500);
        }
    }
    
    public void enviarComando(String modo) {

    if (modo == null || modo.trim().isEmpty()) {

        System.out.println(
                "[CLIENTE] Comando vacío."
        );

        return;
    }

    modo = modo.trim().toUpperCase();

    try {

        enviar(
                "ORD|accion=" + modo
        );

    } catch (IOException e) {

        System.out.println(
                "[CLIENTE] Error enviando comando: "
                + e.getMessage()
        );
    }
}

    private void activarFailSafe() {

        failSafeActivo = true;

        System.out.println(
                "=========================================="
        );

        System.out.println(
                "           FAIL-SAFE ACTIVADO"
        );

        System.out.println(
                "=========================================="
        );

        detenerMotores();
    }

    private void desactivarFailSafe() {

        failSafeActivo = false;

        System.out.println(
                "[FAIL-SAFE] Comunicación restaurada."
        );
    }

    public void detener() {

        corriendo = false;

        detenerMotores();

        desconectarTCP();

        System.out.println(
                "[CLIENTE] Cliente detenido."
        );
    }

    private void dormir(
            long milisegundos) {

        try {

            Thread.sleep(
                    milisegundos
            );

        } catch (InterruptedException e) {

            Thread.currentThread().interrupt();
        }
    }
}