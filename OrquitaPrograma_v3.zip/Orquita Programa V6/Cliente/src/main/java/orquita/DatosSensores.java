package orquita;
public class DatosSensores {

    public static final double DIST_MIN_FISICA = 2.0;
    public static final double DIST_MAX_FISICA = 400.0;

    private final double dist60;
    private final double dist70;
    private final double dist80;
    private final double dist90;
    private final double dist100;
    private final double dist110;
    private final double dist120;
    private final boolean infrarrojoDetecta;
    private final long timestamp;

    public DatosSensores(
            double dist60, double dist70, double dist80,
            double dist90, double dist100, double dist110,
            double dist120, boolean infrarrojoDetecta) {

        this.dist60 = dist60;
        this.dist70 = dist70;
        this.dist80 = dist80;
        this.dist90 = dist90;
        this.dist100 = dist100;
        this.dist110 = dist110;
        this.dist120 = dist120;
        this.infrarrojoDetecta = infrarrojoDetecta;
        this.timestamp = System.currentTimeMillis();
    }

    public boolean esValido() {

        double[] lecturas = getLecturasUltrasonico();

        for (double d : lecturas) {

            if (Double.isNaN(d) || Double.isInfinite(d)) {
                return false;
            }

            if (d < DIST_MIN_FISICA || d > DIST_MAX_FISICA) {
                return false;
            }
        }

        return true;
    }

    public double[] getLecturasUltrasonico() {
        return new double[] {
            dist60, dist70, dist80, dist90, dist100, dist110, dist120
        };
    }

    public double getDistMinima() {

        double min = dist60;

        for (double d : getLecturasUltrasonico()) {
            if (d < min) {
                min = d;
            }
        }

        return min;
    }

    public double getVariacion() {

        double min = Double.MAX_VALUE;
        double max = -Double.MAX_VALUE;

        for (double d : getLecturasUltrasonico()) {

            if (d < min) min = d;
            if (d > max) max = d;
        }

        return max - min;
    }

    public boolean isInfrarrojoDetecta() {
        return infrarrojoDetecta;
    }

    public long getTimestamp() {
        return timestamp;
    }

    public double getDist60() { return dist60; }
    public double getDist70() { return dist70; }
    public double getDist80() { return dist80; }
    public double getDist90() { return dist90; }
    public double getDist100() { return dist100; }
    public double getDist110() { return dist110; }
    public double getDist120() { return dist120; }

    @Override
    public String toString() {
        return String.format(
            "Datos[60=%.1f 70=%.1f 80=%.1f 90=%.1f 100=%.1f "
            + "110=%.1f 120=%.1f min=%.1f var=%.1f ir=%b]",
            dist60, dist70, dist80, dist90, dist100, dist110, dist120,
            getDistMinima(), getVariacion(), infrarrojoDetecta
        );
    }
}