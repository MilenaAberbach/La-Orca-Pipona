package servidororquita;

public class Navegacion {

    // Una canica es una posicion mucho mas cerca que el resto
    private static final double DIST_MAX_CANICA = 80.0;  // cm
    private static final double DIST_MIN_VALIDA = 3.0;   // cm
    private static final double SALTO_MIN_CM    = 15.0;  // cuanto mas cerca que la mediana

    public static String decidir(
            double clasificacion,
            double[] sensores) {

        if (sensores == null || sensores.length < 7) {
            System.out.println("[NAVEGACION] Vector de sensores inválido.");
            return Protocolo.orden(Protocolo.DETENER);
        }

        System.out.println("[NAVEGACION] Clasificación recibida: " + clasificacion);

        // --- Captura: se decide por la forma del barrido, no solo por la red ---
        int pos = buscarCanica(sensores);

        if (pos >= 0) {
            System.out.println("[NAVEGACION] Decisión: CAPTURAR (pos=" + pos + ")");
            return "ORD|accion=CAPTURAR|pos=" + pos;
        }

        if (clasificacion >= 0.5) {
            System.out.println("[NAVEGACION] Decisión: AVANZAR");
            return Protocolo.orden(Protocolo.AVANZAR);
        }

        double izquierda = sensores[0] + sensores[1] + sensores[2];
        double derecha   = sensores[4] + sensores[5] + sensores[6];

        System.out.println("[NAVEGACION] Distancia izquierda: " + izquierda);
        System.out.println("[NAVEGACION] Distancia derecha: " + derecha);

        if (izquierda > derecha) {
            System.out.println("[NAVEGACION] Decisión: IZQUIERDA");
            return Protocolo.orden(Protocolo.IZQUIERDA);
        }

        System.out.println("[NAVEGACION] Decisión: DERECHA");
        return Protocolo.orden(Protocolo.DERECHA);
    }

    // Devuelve el indice 0-6 de la canica, o -1 si no hay ninguna
    private static int buscarCanica(double[] s) {

        int posMin = 0;
        for (int i = 1; i < 7; i++) {
            if (s[i] < s[posMin]) posMin = i;
        }

        double min = s[posMin];
        if (min < DIST_MIN_VALIDA || min > DIST_MAX_CANICA) return -1;

        // mediana de las otras 6 posiciones
        double[] otras = new double[6];
        int k = 0;
        for (int i = 0; i < 7; i++) {
            if (i != posMin) otras[k++] = s[i];
        }
        java.util.Arrays.sort(otras);
        double mediana = (otras[2] + otras[3]) / 2.0;

        if (mediana - min >= SALTO_MIN_CM) return posMin;

        return -1;
    }
}